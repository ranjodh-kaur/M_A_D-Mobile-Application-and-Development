# Tictactoe Android App <a href="https://github.com/Abdullah-Sheikh"><img alt="views" title="Github views" src="https://komarev.com/ghpvc/?username=Abdullah-Sheikh&style=flat-square" width="125"/></a>[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](#) [![GitHub Forks](https://img.shields.io/github/forks/Abdullah-Sheikh/Tictactoe_in_Android.svg?style=social&label=Fork&maxAge=2592000)](https://www.github.com/Abdullah/Tictactoe_in_Android//fork)[![GitHub Issues](https://img.shields.io/github/issues/Abdullah-Sheikh/Tictactoe_in_Android/.svg?style=flat&label=Issues&maxAge=2592000)](https://www.github.com/Abdullah-Sheikh/management-System/issues)[![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat&label=Contributions&colorA=red&colorB=black	)](#)





https://user-images.githubusercontent.com/62107887/130690253-f670eb6f-33ff-4abf-9353-dfc867808554.mp4










# Tic Tac Toe is a free classic puzzle game also known as Noughts and Crosses.

### Our free Tic Tac Toe game offers:

✓ Play with AI (computer)
✓ 2 players game (multiplayer)
✓ game statistics
✓ On or Off sound and vibration.
✓ Attractive Design (Minimal Design)

The Tic Tac Toe game is a game for two players, who take turns marking the spaces in a 3×3 grid. The player who succeeded in placing three respective marks in a horizontal, vertical, or diagonal row wins the game.

In this Tic Tac Toe game you have two options:
-> Play with AI
-> Play with Friend

The Tic Tac Toe is a great way to pass your free time whether you're standing in a line or spending time with your kids. Its offline App means you do not need of internet to play. Because of the simplicity of Tic Tac Toe, it is often used as a pedagogical tool for teaching the concepts of good sportsmanship and the branch of artificial intelligence.



<a href="https://play.google.com/store/apps/details?id=com.techsoldev.tictactoegame" target="_blank"> <img src="https://user-images.githubusercontent.com/62107887/130696039-68b4276e-8b78-4eb6-8aa9-ac2ac681e828.png" width="150" height="70" > </a>




# App Screens


![Screenshot_20210819_010247 2](https://user-images.githubusercontent.com/62107887/130690605-22bf0fa7-9d50-455a-ba8a-02833e571149.jpg)

![Screenshot_20210819_010333 2](https://user-images.githubusercontent.com/62107887/130690643-a23de642-a3b2-428a-879a-163ddcded5e2.jpg)

![Screenshot_20210819_010435 2](https://user-images.githubusercontent.com/62107887/130690652-15b50c29-ccec-44be-9819-c3e88641ae52.jpg)

![Screenshot_20210819_010408](https://user-images.githubusercontent.com/62107887/130690657-6c4265c4-d08f-4314-884b-c8509a6032cf.jpg)









feel free to Star or Fork it and make your changes , then make pull request.

We will appreciate your Changes and Review it 😄

<div align="center">
	<br>
	<br>
	<br>
	<br>
	<img src="https://enterprise.github.com/assets/spinners/octocat-spinner-128-26a44333917854c6794d55eac947b1277fced54f1f60c5df5d93431db8753bc5.gif" width="40" height="40">
	<p>Loading</p>
	<br>
	<br>
	<br>
	<br>
</div>

